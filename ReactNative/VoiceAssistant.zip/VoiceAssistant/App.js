/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Image
} from 'react-native';
import { Provider, connect } from 'react-redux'
import { createStore } from 'redux'
import TopView from './js/View/TopView'
import BottomView from './js/View/BottomView'
import ContentView from './js/View/ContentView'
import { defaultReducer } from './js/Reducer/defaultReducer.js'

var deviceWidth = require('Dimensions').get('window').width;
var deviceHeight = require('Dimensions').get('window').height;

// Store
const store = createStore(defaultReducer)

export default class App extends Component<{}> {
  render() { 
    return (
      <Provider store={store}>
        <View style={styles.container}>
          <Image source={require('./image/background.png')} style={styles.backgroundImage} />
        
          <TopView style={styles.topView} />
        
          <ContentView style={styles.contentView} />
        
          <BottomView style={styles.bottomView}/>
        </View>
      </Provider>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
  },
  backgroundImage: {
    width: deviceWidth,
    height: deviceHeight,
  },
  topView: {
    position:'absolute',
    top: 20,
    left: 0,
    width: deviceWidth,
    height: 44,
  },
  contentView: {
    position:'absolute',
    top: 64,
    left: 0,
    width: deviceWidth,
    height: deviceHeight - 64 - 100,
  },
  bottomView: {
    position:'absolute',
    bottom: 0,
    left: 0,
    width: deviceWidth,
    height: 100,
  },
});
