//
//  ViewController.m
//  VoiceAssistant
//
//  Created by PerTerbin on 2017/12/12.
//  Copyright © 2017年 PerTerbin. All rights reserved.
//

#import "ViewController.h"
#import "VoiceAssistantViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonClicked:(id)sender {
    [self.navigationController pushViewController:[[VoiceAssistantViewController alloc] init] animated:YES];
}

@end
