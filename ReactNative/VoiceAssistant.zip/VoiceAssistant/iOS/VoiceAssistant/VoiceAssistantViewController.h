//
//  VoiceAssistantViewController.h
//  VoiceAssistant
//
//  Created by PerTerbin on 2017/12/12.
//  Copyright © 2017年 PerTerbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VoiceAssistantViewController : UIViewController

@end
