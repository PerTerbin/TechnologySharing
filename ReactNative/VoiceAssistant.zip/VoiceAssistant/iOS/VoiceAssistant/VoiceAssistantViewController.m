//
//  VoiceAssistantViewController.m
//  VoiceAssistant
//
//  Created by PerTerbin on 2017/12/12.
//  Copyright © 2017年 PerTerbin. All rights reserved.
//

#import "VoiceAssistantViewController.h"
#import <React/RCTRootView.h>
#import <React/RCTBridgeModule.h>

@interface VoiceAssistantViewController ()<RCTBridgeModule>

@end

@implementation VoiceAssistantViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    self.view = [self loadRootView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (RCTRootView *)loadRootView {
    NSURL *jsCodeLocation = [NSURL URLWithString:@"http://localhost:8081/index.bundle?platform=ios"];
    RCTRootView *rootView = [[RCTRootView alloc] initWithBundleURL:jsCodeLocation moduleName:@"VoiceAssistant" initialProperties:nil launchOptions:nil];
    
    return rootView;
}

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(dismissWithTimeInterval:(CGFloat)timeInterval) {
    NSLog(@"使用时长：%f", timeInterval);
}


@end
