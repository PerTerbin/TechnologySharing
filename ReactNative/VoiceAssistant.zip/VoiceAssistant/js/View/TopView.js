import React, { Component } from 'react';
import {
  StyleSheet,
  NativeModules,
  View,
  Image,
  TouchableHighlight
} from 'react-native';
import { connect } from 'react-redux'
import ImageButton from './Component/ImageButton'

class TopView extends Component<{}> {
  // Action
  createAction(type) {
    switch (type) {
      case "shake":
        return { type: "ShakeButtonClicked" }
      case "play":
        return { type: "PlayButtonClicked" }
      default:
        return { type: "" }
    } 
  }

  buttonOnPress(type) {
    this.props.onButtonClicked(this.createAction(type));
  }

  closeButtonClicked() {
    var viewController = NativeModules.VoiceAssistantViewController;
    viewController.dismissWithTimeInterval(120);
  }

  render() {
    var shakeImage = this.props.shakeSwitchClose ? require('../../image/top_shake_close.png') : require('../../image/top_shake.png');
    var playImage = this.props.playSwitchClose ? require('../../image/top_play_close.png') : require('../../image/top_play.png');

    return (
      <View style={[styles.topView, this.props.style]}>
      	<ImageButton source={require('../../image/top_avator.png')} style={styles.avator} />

        <ImageButton source={shakeImage} style={styles.shakeButton} onPress={() => {this.buttonOnPress('shake')}} />

        <ImageButton source={playImage} style={styles.playButton} onPress={() => {this.buttonOnPress('play')}} />

        <ImageButton source={require('../../image/top_close.png')} style={styles.closeButton} onPress={() => {this.closeButtonClicked()}} />
      </View>
    );
  }
}

// 映射state
function mapStateToProps(state = { shakeSwitchClose : false, playSwitchClose : false }) {
  return {
    shakeSwitchClose: state.shakeSwitchClose,
    playSwitchClose: state.playSwitchClose,
  }
}

// 映射dispatch
function mapDispatchToProps(dispatch) {
  return {
    onButtonClicked: (action) => dispatch(action)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(TopView);

const styles = StyleSheet.create({
  topView: {
  	flexDirection: 'row',
  	justifyContent: 'flex-end',
  	alignItems: 'center',
  },
  avator: {
  	width: 22,
  	height: 22,
  	position: 'absolute', 
  	left: 16,
  },
  shakeButton: {
  	width: 22,
  	height: 22,
  	marginRight: 16,
  },
  playButton: {
  	width: 22,
  	height: 22,
  	marginRight: 16,
  },
  closeButton: {
  	width: 22,
  	height: 22,
  	marginRight: 16,
  },
});