import React, { Component } from 'react';
import {
  StyleSheet,
  Image,
  TouchableHighlight,
  View
} from 'react-native';

export default class ImageButton extends Component<{}> {
  render() {
    return (
    	<TouchableHighlight style={this.props.style} activeOpacity={0.5} underlayColor="#B5B5B5" onPress={this.props.onPress}>
        <Text style={this.props.TextStyle}>{'a'}</Text>
      </TouchableHighlight>
    );
  }
}
