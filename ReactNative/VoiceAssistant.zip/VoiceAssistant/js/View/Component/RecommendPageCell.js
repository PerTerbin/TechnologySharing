import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableHighlight,
} from 'react-native';
import { connect } from 'react-redux'

var deviceWidth = require('Dimensions').get('window').width;
var deviceHeight = require('Dimensions').get('window').height;

var RecommendPageData = [
  {"title":"智能控制","items":["打开历史成交","帮我买入100手同花顺","打开股民学校","将国投电力加入自选股","打开平安银行五日分时"]},
  {"title":"搜股票","items":["雪球关注前十个股","所属概念包含雄安新区","股价跌破员工持股成本","近一月高管增持大于500万元","重大利好的股票"]},
  {"title":"查数据","items":["格力电器公司高管","中国平安公司高管","美的集团均线角度","上汽集团基本面怎么样","华新水泥dde大单净量"]},
  {"title":"问客服","items":["密码忘记怎么办","不能进行交易了","我身份证过期了怎么办","如何学会炒股","如何查看新股中签结果"]},
];

class RecommendPageCell extends Component<{}> {
  constructor(props) {
    super(props);
    this.state = {selectedIndex: 0};   
  }

  itemOnClicked(pageNo, row) {
    var text = RecommendPageData[pageNo].items[row];
    return () => this.props.itemOnClicked({type:"RecommendPageItemClicked", text:text});
  }

  renderRecommendPage(data, i) {
    var pageNo = i;
    return (
      <View key={i} style={styles.recommendPageView}>
        <View style={styles.recommendPageHeaderView}>
          <Text style={styles.recommendPageHeaderTitle}>{data.title}</Text>
        </View>

        <View>
          {data.items.map((item, i) => 
            <TouchableHighlight  key={i} underlayColor={'rgba(0, 0, 0, 0)'} onPress={this.itemOnClicked(pageNo, i)} >
              <View style={styles.recommendPageItemView}>
                <Text style={styles.recommendPageItemTitle}>{item}</Text>
                <View style={styles.recommendPageItemLine} />              
              </View>
            </TouchableHighlight>
          )}
        </View>

        <TouchableHighlight style={styles.recommendPageChangeButton}>
          <Text style={styles.recommendPageChangeButtonText} onPress={this.onPressTitle}>
            {"不感兴趣，换一批"}
          </Text>
        </TouchableHighlight>
      </View>
    );
  }

  renderCircleDot(data, i, thiz) {
    return (
      <View key={i} style={i == thiz.state.selectedIndex ? styles.circleDotSelected : styles.circleDotUnselected}/>
    );
  }

  scrollViewDidScroll(event, thiz) {
    let width = event.nativeEvent.layoutMeasurement.width;
    let index = parseInt(event.nativeEvent.contentOffset.x / width);
    if (index != thiz.state.selectedIndex) {
      thiz.setState({selectedIndex: index});
    }
  }

  render() {
    return (
      <View>
        <ScrollView 
          style={styles.scrollView} 
          pagingEnabled={true}
          horizontal={true}
          showsHorizontalScrollIndicator={false} 
          onScroll={(event, thiz) => this.scrollViewDidScroll(event, this)}>
          {RecommendPageData.map((data, i) => this.renderRecommendPage(data, i))}
        </ScrollView>
        
        <View style={styles.pageControlView}>
          {RecommendPageData.map((data, i, thiz) => this.renderCircleDot(data, i, this))}
        </View>          
      </View>      
    );
  }
}

// 映射state
function mapStateToProps(state = { dataSource : []}) {
  return {
    dataSource: state.dataSource,
  }
}

// 映射dispatch
function mapDispatchToProps(dispatch) {
  return {
    itemOnClicked: (action) => dispatch(action)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(RecommendPageCell);

const styles = StyleSheet.create({
  scrollView: {
  	width: deviceWidth,
    height: 280,
    marginTop: 8,
  },
  recommendPageView: {
    width: deviceWidth - 32,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 10,
    marginLeft: 16,
    marginRight: 16,
  },
  recommendPageHeaderView: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: 44,
  },
  recommendPageHeaderTitle: {
    color: 'white',
    fontSize: 18,
  },
  recommendPageItemView: {
    justifyContent: 'center',
    height: 40,    
  },
  recommendPageItemTitle: {
    fontSize: 15,
    color: 'white',
    marginLeft: 8,
  },
  recommendPageItemLine: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    width: deviceWidth - 32 - 16,
    height: 0.5,
    position: 'absolute',
    left: 8,
    bottom: 39.5,
  },
  recommendPageChangeButton: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 40,
  },
  recommendPageChangeButtonText: {
    fontSize: 13,
    color: 'rgb(36, 169, 225)',
  },

  pageControlView: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
    height: 15,
    marginBottom: 8,
  },  
  circleDotUnselected: {
      width:6,
      height:6,
      borderRadius:6,
      backgroundColor:'rgba(255, 255, 255, 0.2)',
      marginHorizontal:5,
  },
  circleDotSelected: {
      width:6,
      height:6,
      borderRadius:6,
      backgroundColor:'#ffffff',
      marginHorizontal:5,
  },
});