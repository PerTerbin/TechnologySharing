import React, { Component } from 'react';
import {
  StyleSheet,
  Image,
  TouchableHighlight,
  View
} from 'react-native';

export default class ImageButton extends Component<{}> {
  render() {
    var onPress = () => {};
    if (typeof(this.props.onPress) != 'undefined') {
      onPress = this.props.onPress;
    }
    return (
      <TouchableHighlight style={this.props.style} underlayColor={'rgba(0, 0, 0, 0)'} onPress={onPress}>
          <Image source={this.props.source} />
      </TouchableHighlight>
    );
  }
}
