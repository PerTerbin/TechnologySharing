import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View
} from 'react-native';

export default class NormalTextCell extends Component<{}> {

  render() {
    return (
      <View style={styles.contentView}>
        <View style={styles.backgroundView}>
          <Text style={styles.contentText}>{this.props.text}</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  contentView: {
    flexDirection: 'row',
  	height: 60,
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },
  backgroundView: {
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginLeft: 16,
    marginTop: 8,
    height: 44,
    borderTopRightRadius: 12,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
  },
  contentText: {
    color: 'white',
    fontSize: 16,
    marginLeft: 8,
    marginRight: 8,
  },
});