import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View
} from 'react-native';

export default class QuestionTextCell extends Component<{}> {

  render() {
    return (
      <View style={styles.contentView}>
        <View style={styles.backgroundView}>
          <Text style={styles.contentText}>{this.props.text}</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  contentView: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  	height: 60,
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },
  backgroundView: {
    justifyContent: 'center',
    backgroundColor: '#61486b',
    marginRight: 16,
    marginTop: 8,
    height: 44,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    borderBottomLeftRadius: 12,
  },
  contentText: {
    color: 'white',
    fontSize: 16,
    marginLeft: 8,
    marginRight: 8,
  },
});