import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  TouchableHighlight,
  View,
  TextInput,
  ScrollView,
} from 'react-native';
import { connect } from 'react-redux'
import ImageButton from './Component/ImageButton.js'

class BottomView extends Component<{}> {

  renderRecommendItem() {
    var itemArray = [];
    for (var i = 0; i < BottomRecommendItems.length; i++) {
      var styleArray = [styles.recommendItemButton];
      if (i == 0) {
        styleArray.push({marginLeft: 16});
      }
      if (i == BottomRecommendItems.length - 1) {
        styleArray.push({marginRight: 16}); 
      }
      itemArray.push(
        <RecommendItemButton key={i} title={BottomRecommendItems[i]} style = {styleArray} onButtonClicked={this.props.onButtonClicked} />
      );
    }

    return itemArray;
  }

  render() {
    return (
      <View style={this.props.style}>
        <ScrollView 
          style={styles.scrollView} 
          contentContainerStyle={styles.scrollViewContainerStyle}
          horizontal={true}
          showsHorizontalScrollIndicator={false} >
          {this.renderRecommendItem()}
        </ScrollView>
        
        <View style={styles.bottomView}>  
          <View style={styles.editView}>
            <ImageButton source={require('../../image/bottom_memu.png')} style={styles.menuButton} />
            <TextInput style={styles.editTextInput} placeholder={'中国平安公司高管'} placeholderTextColor={'rgba(255, 255, 255, 0.3)'} />
          </View>

          <ImageButton source={require('../../image/bottom_voice.png')} style={styles.voiceButton} />
        </View>

      </View>
    );
  } 
} 

const BottomRecommendItems = ['推荐问句', '龙虎榜', '今日盘面', '形态搜索', '主题投资', 'K线训练营', '新股IPO'];


class RecommendItemButton extends Component<{}> {
  
  bottomButtonOnClicked(text) {
    if (text == '推荐问句') {
      return () => this.props.onButtonClicked({type: 'BottomRecommendButtonClicked', text: text});
    } else {
      return () => this.props.onButtonClicked({type: 'BottomOtherButtonClicked', text: text});
    }
  } 

  render() {
    return (
      <TouchableHighlight onPress={this.bottomButtonOnClicked(this.props.title)} underlayColor={'rgba(0, 0, 0, 0)'}>
        <View style={this.props.style} >
          <Text style={styles.recommendItemButtonTitle}>
            {this.props.title}
          </Text>
        </View>      
      </TouchableHighlight>
    );
  }
}

// 映射state
function mapStateToProps(state = { dataSource : []}) {
  return {
    dataSource: state.dataSource,
  }
}

// 映射dispatch
function mapDispatchToProps(dispatch) {
  return {
    onButtonClicked: (action) => dispatch(action)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(BottomView);

const styles = StyleSheet.create({
  scrollView: {
    flexDirection: 'row',
    height: 44,
  },
  scrollViewContainerStyle: {
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },

  recommendItemButton: {
    justifyContent: 'center',
    borderColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  recommendItemButtonTitle: {
    fontSize: 14,
    textAlign: 'center',
    color: 'white',
    marginLeft: 10,
    marginRight: 10,
  },

  bottomView: {
  	flexDirection: 'row',
  },

  editView: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    height: 38,
    marginLeft: 16,
    marginRight: 8,
    marginBottom: 16,
    borderRadius: 19,
  },
  menuButton: {
    width: 15,
    height: 15,
    marginLeft: 12,
  },
  editTextInput: {
    flex: 1,
    marginLeft: 12,
    marginRight: 16,
  },

  voiceButton: {
    width: 38,
    height: 38,
    marginRight: 16,
    marginBottom: 16,
  }
});