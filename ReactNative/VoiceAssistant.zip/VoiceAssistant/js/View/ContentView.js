import React, { Component } from 'react';
import {
  StyleSheet,
  ListView,
  ScrollView,
  Text,
} from 'react-native';
import { connect } from 'react-redux'
import RecommendPageCell from './Component/RecommendPageCell'
import NormalTextCell from './Component/NormalTextCell'
import QuestionTextCell from './Component/QuestionTextCell'

class ContentView extends Component<{}> {
  
  constructor(props) {
    super(props);
        
    this.scrollView;
  }

  
  renderListItem(rowData, sectionID, rowId) {
    switch (rowData.type) {
      case 'Answer':
        return <NormalTextCell text={rowData.text} />;
      case 'Recommend':
        return <RecommendPageCell />; 
      case 'Question':
        return <QuestionTextCell text={rowData.text} />;
    }
  }

  componentDidUpdate(prevProps, prevState) {
    setTimeout(() => {this.scrollView.scrollToEnd();}, 10);
  }

  render() {
    console.log(this.props);
    var dataSource = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2}).cloneWithRows(this.props.dataSource);

    return (
      <ListView
        ref={(scrollView) => { this.scrollView = scrollView; }}
        style={[styles.contentView, this.props.style]}
        showsVerticalScrollIndicator={false}
        dataSource={dataSource}
        renderRow={this.renderListItem}
      />
    );
  }
}

// 映射state
function mapStateToProps(state = { dataSource : []}) {
  return {
    dataSource: state.dataSource,
  }
}

// 映射dispatch
function mapDispatchToProps(dispatch) {
  return {
    onButtonClicked: (action) => dispatch(action)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ContentView);

const styles = StyleSheet.create({
  contentView: {
  	backgroundColor: 'rgba(0, 0, 0, 0)',
  },
});