
const defaultDataSource = [{'type':'Answer', 'text':'晚上好，我是你的股市助手小花'}, {'type':'Recommend'}];

export function defaultReducer(state = { shakeSwitchClose : false, playSwitchClose: false , dataSource: defaultDataSource}, action) {
  var newState = deepClone(state);
  switch (action.type) {

    case 'ShakeButtonClicked':
    	newState.shakeSwitchClose = !newState.shakeSwitchClose;
    	if (newState.shakeSwitchClose) {
    		newState.dataSource.push({'type':'Answer', 'text':'摇一摇唤醒已关闭'});
    	} else {
    		newState.dataSource.push({'type':'Answer', 'text':'摇一摇唤醒已开启'});
    	}    	
    	return newState;

    case 'PlayButtonClicked':
    	newState.playSwitchClose = !newState.playSwitchClose;
    	if (newState.playSwitchClose) {
    		newState.dataSource.push({'type':'Answer', 'text':'语音播报已关闭'});
    	} else {
    		newState.dataSource.push({'type':'Answer', 'text':'语音播报已开启'});
    	} 
    	return newState;

    case 'RecommendPageItemClicked':
    	newState.dataSource.push({'type':'Question', 'text':action.text}); 
        newState.dataSource.push({'type':'Answer', 'text':'没有找到符合条件的结果'}); 
    	return newState;

    case 'BottomRecommendButtonClicked':
        newState.dataSource.push({'type':'Question', 'text':action.text}); 
        newState.dataSource.push({'type':'Recommend'}); 
        return newState;
        
    case 'BottomOtherButtonClicked':
        newState.dataSource.push({'type':'Question', 'text':action.text}); 
        newState.dataSource.push({'type':'Answer', 'text':'没有找到符合条件的结果'}); 
        return newState;

    default:
      return state;
  }
}


function deepClone(initalObj) {
    var obj = {};
    obj = JSON.parse(JSON.stringify(initalObj));
    return obj;
}