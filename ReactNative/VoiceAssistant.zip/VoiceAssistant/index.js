import { AppRegistry } from 'react-native';
import App from './App';
import test from './test';

AppRegistry.registerComponent('VoiceAssistant', () => App);
